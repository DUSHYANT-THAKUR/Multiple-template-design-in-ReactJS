
import Home from "./Page/Home"
import "bootstrap/dist/css/bootstrap.min.css";
import "bootstrap/dist/js/bootstrap.bundle.min";

function App() {
  return (
<>
<Home />
</>
  );
}

export default App;

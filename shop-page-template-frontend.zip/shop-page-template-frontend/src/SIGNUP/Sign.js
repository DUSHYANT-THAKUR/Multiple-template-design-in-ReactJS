import React, { useState,useEffect } from 'react';
import './Sign.css';
import { Button } from 'react-bootstrap';
import axios from 'axios';
import {Dialog,DialogTitle,Grid,TextField,DialogActions,Box,DialogContentText,DialogContent,Divider} from '@mui/material'
import { Color } from 'react-bootstrap/esm/types';


function Sign() {
  const [Name, setName] = useState('');
  const [Email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirm_password, setConfirm_password] = useState('');
  const [Message,setMessage] = useState('')
  const [open,setOpen]=useState(true)
 // const [open,setOpen]=useState(false)

   // setOpen(true);


  const handleClose = () => {
    setOpen(false);
  };


  async function handleSubmit(e) {
    console.log("hello")
    e.preventDefault();
    const formData = new FormData();
    formData.append('name', Name);
    formData.append('Email', Email); // Corrected key name to 'email'
    formData.append('password', password);
    formData.append('confirm_password', confirm_password);

    try {
      const config = {
        headers: {
          'Content-Type': 'application/json', // Corrected header name
          Accept: 'application/json',
        },
      };

      const result = await axios.post('http://localhost:4000/SignUp', formData, config);
      console.log(result); // You can handle the response data as needed
      setMessage(result.data.Message)
    
    } catch (error) {
      console.log(error);
    }
  }

  return (

<React.Fragment>

  <Dialog
    open={open}
    onClose={handleClose}
    maxWidth="md" 
    fullWidth 
    PaperProps={{
      style: {
        minWidth: '50%', // Set the minimum width
        minHeight: '70%', // Set the minimum height
      },
    }}
  >
    <DialogTitle style={{backgroundColor:"#651fff"}}>Sign Up</DialogTitle>
    <Divider />
    <DialogContent>
      <DialogContentText>
        You can set my maximum width and whether to adapt or not.
      </DialogContentText>
      <Box
        noValidate
        component="form"
        sx={{
          display: 'flex',
          flexDirection: 'column',
          m: 'auto',
          width: 'fit-content',
        }}
      >
        {/* Your form fields or content */}
      </Box>
    </DialogContent>
    <DialogActions>
      <Button onClick={handleSubmit} style={{marginRight:"100px",marginBottom:"50px"}}>Submit</Button>
    </DialogActions>
  </Dialog>
</React.Fragment>

  );
}

export default Sign;


// import * as React from 'react';
// import Button from '@mui/material/Button';
// import TextField from '@mui/material/TextField';
// import Dialog from '@mui/material/Dialog';
// import DialogActions from '@mui/material/DialogActions';
// import DialogContent from '@mui/material/DialogContent';
// import DialogContentText from '@mui/material/DialogContentText';
// import DialogTitle from '@mui/material/DialogTitle';

// export default function FormDialog() {
//   const [open, setOpen] = React.useState(false);

//   const handleClickOpen = () => {
//     setOpen(true);
//   };

//   const handleClose = () => {
//     setOpen(false);
//   };

//   return (

//   );
// }
// import * as React from 'react';
// import Box from '@mui/material/Box';
// import Button from '@mui/material/Button';
// import Dialog, { DialogProps } from '@mui/material/Dialog';
// import DialogActions from '@mui/material/DialogActions';
// import DialogContent from '@mui/material/DialogContent';
// import DialogContentText from '@mui/material/DialogContentText';
// import DialogTitle from '@mui/material/DialogTitle';
// import FormControl from '@mui/material/FormControl';
// import FormControlLabel from '@mui/material/FormControlLabel';
// import InputLabel from '@mui/material/InputLabel';
// import MenuItem from '@mui/material/MenuItem';
// import Select, { SelectChangeEvent } from '@mui/material/Select';
// import Switch from '@mui/material/Switch';

// export default function MaxWidthDialog() {
//   const [open, setOpen] = React.useState(false);
//   const [fullWidth, setFullWidth] = React.useState(true);
//   const [maxWidth, setMaxWidth] = React.useState<DialogProps['maxWidth']>('sm');



//   const handleMaxWidthChange = (event: SelectChangeEvent<typeof maxWidth>) => {
//     setMaxWidth(
//       // @ts-expect-error autofill of arbitrary value is not handled.
//       event.target.value,
//     );
//   };

//   const handleFullWidthChange = (event: React.ChangeEvent<HTMLInputElement>) => {
//     setFullWidth(event.target.checked);
//   };

//   return (
    
//   );
// }


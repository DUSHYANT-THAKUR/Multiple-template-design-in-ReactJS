import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Login from './LOGIN/Login';
import Logout from './LOGOUT/Logout';
import MainPage from './Main'; 
import SignUp from '../src/SIGNUP/Sign'

function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<Login />} />
        <Route path="/main" element={<MainPage />} />
        <Route path="/Logout" element={<Logout />} />
        <Route path="/SignUp" element={<SignUp />} />
        {/* Add other routes if needed */}
      </Routes>
    </Router>
  );
}

export default App;

import React from 'react'
import './Navbar.css'
import { Link } from 'react-router-dom'
import { FaFacebook,FaInstagram,FaTwitter } from "react-icons/fa";
import  backgroundImage  from '../../IMAGE/food2.avif'
import  Image  from '../../IMAGE/pic.jpg'
import Logout from '../../LOGOUT/Logout';

function Navbar() {
  
  return (
    <>
          
              {/* <div className='col-3'>
             
                <marquee behavior="scroll" direction="right" scrollamount="12">
                 <h2><span style={{color:"red"}}>UbankConnect</span> <span style={{color:"yellow"}}>UbankConnect</span>  <span style={{color:"White"}}>UbankConnect</span></h2></marquee>
          
              </div> */}
              
              <div className='row' style={{ backgroundImage: `url(${backgroundImage})`, backgroundSize: 'cover', height: "500px", width: "100%",backgroundRepeat: 'no-repeat' }}>
                <div className='col-md-1'>
                  <img src={Image} style={{width: "100px",height: "100px",borderRadius:"50px",marginLeft: "20px"}}/>
                </div>
     <div className='col-md-8'>
      <div>
        <ul>
          <li><a href='#'>Home</a></li>
          <li><a href='#'>Recipes</a></li>
          <li><a href='#'>Our Special Dish</a></li>
          <li><a href='#'>My Account</a></li>
          <li><a href='#'>Contact Us</a></li>
          {/* <li><a href={<Logout />}>Logout</a></li> */}
          <li><Link to='/Logout'>Logout</Link></li>
        </ul>
      </div>
     </div>
     <div className='row'>
        <div className='col-md-12' >
          <span>
          <marquee behavior="scroll" direction="right" scrollamount="12"><h2 style={{textAlign:"center",color:"#000000"}}> Welcome to My Online Food Area</h2></marquee>
          </span>
       
        <span>
        <marquee behavior="scroll" direction="left" scrollamount="12"><h2 style={{textAlign:"center",color:"blue"}}> Welcome to My Online Food Area</h2></marquee></span>
          <div className='row'>
            <div className='col-md-12' id='header-content'>
              Welcome to URO Food Delivery Online. We are providing Delicious Food Items, Very Sweet Taste And Good Design Cakes Four Your Family Function, Birthday Parties , Anniversary function and many more things.Here you can buy items and cake items from Online and Offline becase We are providing very good quality also good quantity items ,For online order you can select food and cake and direct buy and you can click on the contact us for find our contact details  & direct call and buy option or you can click the button for visit our offline store
            </div>
          </div>
        </div>

      </div>
      </div>
     
      </>
  )
}

export default Navbar;
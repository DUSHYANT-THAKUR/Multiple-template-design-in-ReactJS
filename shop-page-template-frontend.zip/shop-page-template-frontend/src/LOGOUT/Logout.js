import React, { useEffect } from 'react'
import { useNavigate } from 'react-router-dom'

function Logout() {
    
    const navigate = useNavigate();
  return (
    <div>
        {
            useEffect(
                ()=>{
                  localStorage.clear();
                    navigate('/')
                },[])
            
        }
    </div>
  )
}

export default Logout
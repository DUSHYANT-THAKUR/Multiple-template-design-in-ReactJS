
import Card from 'react-bootstrap/Card';
import './Card.css'
import fooding from '../IMAGE/fooding.avif'
import Cake from '../IMAGE/Cake.avif'
import delivery from '../IMAGE/delivery.avif'
import product from '../IMAGE/product_back.avif'

function Card2() {
  return (
    <div className='container-fluid' id='card-container' >

      <div className='card'>
        <Card>
          <Card.Img variant="top" className='card-image' src={fooding} />
          <Card.Body>
            <Card.Title className='card-title'><h2>Food Ordering</h2></Card.Title>
            <Card.Text className='card-text'>
              Here is our food website where you can find any types of delicious items which are affordable for all types of families.
              You can visit our special Dish item's which is really and special and available only in our URO foos court
            </Card.Text>
          </Card.Body>

        </Card>
      </div>

      <div className='card'>
        <Card>
          <Card.Img variant="top" className='card-image' src={delivery} />
          <Card.Body>
            <Card.Title className='card-title'><h2>Free Home Delivery</h2></Card.Title>
            <Card.Text className='card-text'>
              you are providing free food delivery services for all Customers. You can directly call with our helpline number or buy from our websites and our delivery boy will go with the item in your door steps
            </Card.Text>
          </Card.Body>

        </Card>
      </div>


      <div className='card'>
        <Card>
          <Card.Img variant="top" className='card-image' src={Cake} />
          <Card.Body>
            <Card.Title className='card-title'><h2>Cake Ordering</h2></Card.Title>
            <Card.Text className='card-text'>
              You can buy food item's and also buy Cake item's for any design because we are providing all types & design of cake item's within 2-4 hours , also we are providing free cake delivery.
            </Card.Text>
          </Card.Body>

        </Card>
      </div>



    </div>
  )

}
export default Card2;

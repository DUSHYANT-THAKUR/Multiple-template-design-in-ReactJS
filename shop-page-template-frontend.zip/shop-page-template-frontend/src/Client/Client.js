import React from 'react'
import './Client.css'
import employee from '../IMAGE/employee3.jpg';
import microsoft from '../IMAGE/microsoft-icon.png';
import google from '../IMAGE/Google.png';
import hp from '../IMAGE/hp.png';
import spotify from '../IMAGE/spotify-icon.png';
import apple from '../IMAGE/apple.gif'
import { Button } from 'react-bootstrap';

function Client() {
  return (
    <div className='contaier-fluid' style={{borderTop:"5px solid blue",marginTop:"10px",backgroundImage:`url(${employee})`, backgroundSize: 'cover', height: "700px", width: "100%",backgroundRepeat: 'no-repeat' ,borderBottom:"5px solid blue"}}>
        <div className='row' style={{textAlign:"center"}}><h2>Our Client</h2></div>
        <div className='row' id="client-img-container">
            <div className='col-2'><img src={microsoft}/></div>
            <div className='col-2'><img src={google}/></div>
            <div className='col-2'><img src={hp}/></div>
            <div className='col-2'><img src={spotify}/></div>
            <div className='col-2'><img src={apple}/></div>
            {/* <div className='col-2'><img src={}/></div> */}

        </div>
        <div className='row' id="client-img-title">
          <div className='col-2'>microsoft</div>
          <div className='col-2'>Google</div>
          <div className='col-2' style={{paddingLeft: "70px"}}>Hp</div>
          <div className='col-2' style={{paddingLeft: "45px"}}>spotify</div>
          <div className='col-2' style={{paddingLeft: "60px"}}>Apple</div>
           
        </div>
    </div>
    
  )
}

export default Client;
import React, { useState,useEffect } from 'react';
import './Contact.css';
import { Button } from 'react-bootstrap';
import axios from 'axios';

function Contact() {
  const [Name, setName] = useState('');
  const [Email, setEmail] = useState('');
  const [Mobile, setMobile] = useState('');
  const [Suggestion, setSuggestion] = useState('');
  const [Message,setMessage] = useState('')

  useEffect(() => {
    if (Message === 'Saved Successfully') {
      console.log("hello");
      setName('');
      setEmail('');
      setMobile('');
      setSuggestion('');
    }
  }, [Message]);

  async function handleSubmit(e) {
    console.log("hello")
    e.preventDefault();
    const formData = new FormData();
    formData.append('name', Name);
    formData.append('email', Email); // Corrected key name to 'email'
    formData.append('mobile', Mobile);
    formData.append('suggestion', Suggestion);

    try {
      const config = {
        headers: {
          'Content-Type': 'application/json', // Corrected header name
          Accept: 'application/json',
        },
      };

      const result = await axios.post('http://localhost:4000/contact', formData, config);
      console.log(result); // You can handle the response data as needed
      setMessage(result.data.Message)
    
    } catch (error) {
      console.log(error);
    }
  }

  return (
    <div className='container-fluid' style={{ border: '10px solid blue' }}>
      <form style={{ paddingTop: 30 }} onSubmit={handleSubmit}>
        <div className='row'>
          <div className='col-12'>
            <h1 style={{ textAlign: 'center' }}>Contact Us</h1>
          </div>
        </div>
        <div className='row' style={{ paddingLeft: 400, paddingBottom: 100 }}>
          <div className='col-8'>
            <label>Name</label>
            <input type='text' className='form-control' placeholder='Name' onChange={(e) => setName(e.target.value)} />
          </div>
          <div className='col-8'>
            <label>E-mail</label>
            <input type='text' className='form-control' placeholder='E-mail' onChange={(e) => setEmail(e.target.value)} />
          </div>
          <div className='col-8'>
            <label>Mobile No</label>
            <input type='text' className='form-control' placeholder='Mobile No' onChange={(e) => setMobile(e.target.value)} />
          </div>
          <div className='col-8'>
            <label>Suggestion</label>
            <textarea
              className='form-control'
              placeholder='Suggestion'
              onChange={(e) => setSuggestion(e.target.value)}
            />
          </div>
        </div>
        <div style={{color : "green",marginLeft:"400px",fontWeight:"bold"}}>
          {Message}
        </div>
        <div className='col-2'>
          <Button variant='primary' type='submit' size='lg' style={{ marginLeft: '1100px', display: 'block', marginBottom: '100px' }}>
            Submit
          </Button>
        </div>
      </form>
    </div>
  );
}

export default Contact;

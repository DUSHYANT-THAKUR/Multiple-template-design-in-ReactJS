import React from 'react'
import Navbar from "./Component/NAVBAR/Navbar";
import Cardsection from './CARD/Card2'
import Contact from "./CONTACT/Contact";
import Client from "./Client/Client";
import product from './IMAGE/product_back.avif'

function Main() {
  return (
    
<div className="container-fluid">
  {/* navbar section */}
<section>
  <Navbar />
</section>
{/* services section */}
<section>
  <div className="row">
    <div className="col-12">
      <h1 style={{textAlign:"center",marginTop:40}}>Our services</h1>
    </div>
  </div>
</section>

{/* card section  */}
<section style={{backgroundImage:`url(${product})`, backgroundSize: 'cover',height:900,backgroundRepeat: 'no-repeat'}}>
  <Cardsection />
</section>
{/* Client section */}

<section>
<Client />
</section>

{/* Contact section */}
<section>
  <Contact />
</section>
</div>
  )
}

export default Main;